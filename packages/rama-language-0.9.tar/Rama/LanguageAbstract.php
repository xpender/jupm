<?php
/**
 * X-Rama
 *
 * Language class
 *
 * @package net.bigpoint.rama.language
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 */
abstract class Rama_LanguageAbstract
{
    /**
     * Language path
     *
     * @var string
     */
    private $_sLanguagePath;

    /**
     * Locale used
     *
     * @var string
     */
    private $_sLocale;

    /**
     * Compile cache dir
     *
     * @var string
     */
    private $_sCompileDir;

    /**
     * Recompile everything?
     *
     * @var bool
     */
    private $_bForceCompile = false;

    /**
     * Compiled and loaded lang cache stuff
     *
     * @var array
     */
    private $_aCache;

    /**
     * __construct
     *
     * @param string $sLanguagePath
     * @param string $sLocale
     * @param string $sCompileDir optional
     * @param string $bForceCompile optional - defaults to false
     * @return Rama_Language
     */
    public function __construct($sLanguagePath, $sLocale, $sCompileDir = null, $bForceCompile = false)
    {
        $this->setLanguagePath($sLanguagePath);
        $this->setLocale($sLocale);

        if (null === $sCompileDir) {
            $sCompileDir = getTmpDir('language');
        }

        $this->setCompileDir($sCompileDir);

        $this->_bForceCompile = $bForceCompile;
    }

    /**
     * abstract getter for Rama_Template_ScriptingCompiler
     *
     * @return Rama_Template_ScriptingCompiler
     */
    abstract protected function _getScriptingCompiler();

    /**
     * set path to langauge sources
     *
     * @param string $sLanguagePath
     */
    public function setLanguagePath($sLanguagePath)
    {
        if (false === is_dir($sLanguagePath)) {
            throw new Rama_Language_Exception(
                "'" . $sLangaugePath . '\' is not a valid dir'
                );
        }

        if (substr($sLanguagePath, -1) != '/') {
            $sLanguagePath .= '/';
        }

        $this->_sLanguagePath = $sLanguagePath;
    }

    /**
     * set locale
     *
     * @param string $sLocale
     */
    public function setLocale($sLocale)
    {
        if (!in_array(strlen($sLocale), array(2, 3, 5))) {
            throw new Rama_Language_Exception(
                'Invalid locale - incorrect length'
                );
        }

        $this->_sLocale = $sLocale;
    }

    /**
     * Sets the dir for output of compiled files
     *
     * @param string $sCompileDir
     */
    public function setCompileDir($sCompileDir)
    {
        if (false === is_dir($sCompileDir)) {
            throw new Rama_Language_Exception(
                "'" . $sCompileDir . '\' is not a valid dir'
                );
        }

        if (substr($sCompileDir, -1) != '/') {
            $sCompileDir .= '/';
        }

        $this->_sCompileDir = $sCompileDir;
    }

    /**
     * returns locale
     *
     * @return string
     */
    public function getLocale()
    {
        return $this->_sLocale;
    }

    /**
     * parses a xml file
     *
     * @param string $sFilePath
     * @return array
     */
    private function _parseFile($sFilePath)
    {
        // load xml
        $oXml = new Rama_Language_ParserUtil($sFilePath);

        // get array of xml ;9
        $aParsed = array();
        
        $aXmlLanguage = $oXml->getElementTree('language');

        foreach ($aXmlLanguage['children'] as $aXmlCategory) {
            foreach ($aXmlCategory['children'] as $aXmlItem) {
                $aParsed[$aXmlItem['attrs']['name']] = $aXmlItem['cdata'];
            }
        }

        return $aParsed;
    }

    /**
     * Rebuilds a xml file
     * and caches it
     *
     * @param string $sFile
     * @param string $sCacheFile
     * @return bool
     */
    private function _buildFile($sFile, $sCacheFile)
    {
        // file path
        $sFilePath = $this->_sLanguagePath . $this->_sLocale . '/' . $sFile . '.xml';

        if (false === file_exists($sFilePath)) {
            return false;
        }

        // parse xml file
        $aParsed = $this->_parseFile($sFilePath);

        // build cache file
        $sBuffer = "<?php\n/**\n * Language Cache File\n * Do not modify this file, it will be overwritten\n **/\n\n";

        // go through parsed stuff - and generate the cache file
        foreach ($aParsed as $sKey => $sValue) {
            $sBuffer .=
                  "\$this->_aCache['"
                . $this->_sLocale . "']['"
                . $sFile
                . "']['items']['"
                . $sKey
                . "'] = '"
                . str_replace(array('\\', "'"), array('\\\\', "\'"), $sValue)
                . "';\n";
        
            if (strpos($sValue, '{') !== false) {
                $sBuffer .=
                  "\$this->_aCache['"
                . $this->_sLocale . "']['"
                . $sFile
                . "']['dynamicItems']['"
                . $sKey
                . "'] = '"
                . str_replace("'", "\'", $this->_getScriptingCompiler()->compileString($sKey, $sValue))
                . "';\n";
            }
        }

        // write cache file
        $rFileHandle = fopen($sCacheFile, 'w');
        fwrite($rFileHandle, $sBuffer);
        fclose($rFileHandle);

        // clear buffer
        unset($aParsed);
        unset($sBuffer);

        return true;
    }
   
    /**
     * Loads cache file
     * or rebuilds it if needed
     *
     * @param string $sFile
     */
    private function _loadFile($sFile)
    {
        $sCacheFile = $this->_sCompileDir . 'cache.' . $this->_sLocale . '.' . $sFile . '.php';

        if ($this->_bForceCompile || !file_exists($sCacheFile)) {
            if (!$this->_buildFile($sFile, $sCacheFile)) {
                throw new Rama_Language_Exception(
                    'failed to build language-file ' . $sFile
                    );
            }
        }

        require $sCacheFile;
    }
    
    /**
     * Checks if given key exists in the xml file
     *
     * @param string $sKey
     * @return bool
     */
    public function exist($sKey)
    {
        // check key
        if (!preg_match('/^[a-z]{2,}\.[a-zA-Z0-9]+\.(.*)$/', $sKey)) {
            return false;
        }

        // get file name
        $aTmp = @explode('.', $sKey);

        $sFile = $aTmp[0] . '.' . $aTmp[1];

        // need to load the cache for this file?
        if (false === is_array($this->_aCache[$this->_sLocale][$sFile])) {
            $this->_loadFile($sFile);
        }

        // item exists?
        if (isset($this->_aCache[$this->_sLocale][$sFile]['items'][$sKey])) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns given key, if not existent the result is the key
     *
     * @param string $sKey
     * @return string
     */
    public function get($sKey)
    {
        // check key
        if (!preg_match('/^[a-z]{2,}\.[a-zA-Z0-9]+\.(.*)$/', $sKey)) {
            throw new Rama_Language_Exception(
                'Invalid key given'
                );
        }

        // get file name
        $aTmp = @explode('.', $sKey);

        $sFile = $aTmp[0] . '.' . $aTmp[1];
       
        // need to load the cache for this file?
        if (false === is_array($this->_aCache[$this->_sLocale][$sFile])) {
            $this->_loadFile($sFile);
        }

        // item exists?
        if (isset($this->_aCache[$this->_sLocale][$sFile]['items'][$sKey])) {
            return $this->_aCache[$this->_sLocale][$sFile]['items'][$sKey];
        } else {
            return $sKey;
        }

    }
    
    public function getDynamicVariable($sKey, $aVariables = array(), Rama_Template $oTemplate)
    {
        $sStaticItem = $this->get($sKey);

        if ($sStaticItem != $sKey) {
            $aTmp = @explode('.', $sKey);

            $sFile = $aTmp[0] . '.' . $aTmp[1];

            if (isset($this->_aCache[$this->_sLocale][$sFile]['dynamicItems'][$sKey])) {
                if (count($aVariables) > 0) {
                    $oTemplate->assign($aVariables);
                }
            
                return $oTemplate->fetchString($this->_aCache[$this->_sLocale][$sFile]['dynamicItems'][$sKey]);
            }
        }

        return $sStaticItem;
    }
}
