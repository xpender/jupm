<?php
/**
 * X-Rama
 *
 * Language class exception
 *
 * @package net.bigpoint.rama.language
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 */
class Rama_Language_Exception extends Rama_Exception
{
}
