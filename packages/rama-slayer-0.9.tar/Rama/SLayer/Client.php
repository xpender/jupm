<?php
/**
 * X-Rama
 *
 * SLayer Client (without wired GameAPI dependencies)
 *
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 * @package net.bigpoint.rama.slayer
 */
class Rama_SLayer_Client
{
    const GDATA_NAMESPACE = 'bigpoint';

    const CONFIG_KEY = 'slayer_settings';

    private $_oConfig;

    private $_bIsDev;

    private $_iDefaultProjectId;

    private $_iProjectId;

    private $_iAffiliateId;

    public function __construct($bIsDev, $iDefaultProjectId, $iProjectId, $iAffiliateId)
    {
        $this->_bIsDev = $bIsDev;

        $this->_iDefaultProjectId = $iDefaultProjectId;
        $this->_iProjectId = $iProjectId;
        $this->_iAffiliateId = $iAffiliateId;

        $this->_loadConfig();
    }

    private function _loadConfig()
    {
        $aConfig = Bigpoint_Service_GlobalData::getData(self::GDATA_NAMESPACE, self::CONFIG_KEY);

        if ($this->_bIsDev) {
            $this->_oConfig = new Zend_Config(
                $aConfig['development']['v1']
                );
        } else {
            $this->_oConfig = new Zend_Config(
                $aConfig['production']['v1']
                );
        }
    }

    private function _sendRequest($sPath, array $aParams = array(), $sMethod = 'GET')
    {
        $sUri = (string)$this->_oConfig->server->url;

        $sPath = $this->_oConfig->server->path . $sPath;

        $aParams['gameID'] = $this->_iDefaultProjectId;
        $aParams['instanceID'] = $this->_iProjectId;
        $aParams['affiliateID'] = $this->_iAffiliateId;
        $aParams['nc'] = md5(uniqid());

        // do sign the request if required
        if ($this->_oConfig->access->auth == 1) {
            $sSignature = new Zend_Oauth_Signature_Hmac($this->_oConfig->access->secret, null, 'sha1');

            $aParams['signature'] = $sSignature->sign($aParams, $sMethod, $sUri);
        }
        
        $oClient = new Zend_Rest_Client($sUri);

        $oHttpClient = Zend_Rest_Client::getHttpClient();

        $oHttpClient->setConfig(array(
            'maxredirects' => 0,
            'timeout'      => 5)
        );

        try {
            if ($sMethod === 'POST') {
                $oResponse = $oClient->restPost($sPath, $aParams);
            } else {
                $oResponse = $oClient->restGet($sPath, $aParams);
            }
        } catch (Exception $e) {
            throw new Rama_SLayer_Exception('Service unavailable' . $e->getMessage(), 500);
        }

        $sBody = $oResponse->getBody();

        if (empty($sBody)) {
            throw new Rama_SLayer_Exception('Response body is empty', 500);
        }
        
        try {
            $aResponse = Zend_Json_Decoder::decode($sBody);
        } catch (Zend_Json_Exception $e) {
            throw new Rama_SLayer_Exception(
                'Response is invalid json',
                500
                );
        }

        if ($aResponse['meta']['success'] === false) {
            throw new Rama_SLayer_Exception(
                $aResponse['meta']['errorMsg'],
                $aResponse['meta']['error']
                );
        }
        
        return $aResponse['data'];
    }

    public function friendShipList($iUserId)
    {
        $aParams = array(
            'userKeyID' => $iUserId
            );
    
        return $this->_sendRequest('/friendship/list', $aParams);
    }

    public function friendShipReceivedInvites($iUserId)
    {
        $aParams = array(
            'userKeyID' => $iUserId
            );

        return $this->_sendRequest('/friendship/invitations', $aParams);
    }

    public function friendShipSendInvites($iUserId)
    {
        $aParams = array(
            'userKeyID' => $iUserId
            );

        return $this->_sendRequest('/friendship/invited', $aParams);
    }

    public function friendShipInvite($iSenderGlobalAccountId, $iSenderUserId, $iReceiverGlobalAccountId, $iReceiverUserId)
    {
        $aParams = array(
            'inviterID' => $iSenderGlobalAccountId,
            'inviterKeyID' => $iSenderUserId,
            'invitedID' => $iReceiverGlobalAccountId,
            'invitedKeyID' => $iReceiverUserId
            );
        
        return $this->_sendRequest('/friendship/invite', $aParams, 'POST');
    }

    public function friendShipConfirm($iReceiverGlobalAccountId, $iReceiverUserId, $iSenderGlobalAccountId, $iSenderUserId)
    {
        $aParams = array(
            'invitedID' => $iReceiverGlobalAccountId,
            'invitedKeyID' => $iReceiverUserId,
            'inviterID' => $iSenderGlobalAccountId,
            'inviterKeyID' => $iSenderUserId
            );
    
        return $this->_sendRequest('/friendship/confirm', $aParams, 'POST');
    }

    public function friendShipDecline($iReceiverGlobalAccountId, $iReceiverUserId, $iSenderGlobalAccountId, $iSenderUserId)
    {
        $aParams = array(
            'invitedID' => $iReceiverGlobalAccountId,
            'invitedKeyID' => $iReceiverUserId,
            'inviterID' => $iSenderGlobalAccountId,
            'inviterKeyID' => $iSenderUserId
            );
    
        return $this->_sendRequest('/friendship/decline', $aParams, 'POST');
    }

    public function friendShipCancel($iGlobalAccountId_1, $iUserId_1, $iGlobalAccountId_2, $iUserId_2)
    {
        $aParams = array(
            'userID1' => $iGlobalAccountId_1,
            'userKeyID1' => $iUserId_1,
            'userID2' => $iGlobalAccountId_2,
            'userKeyID2' => $iUserId_2
            );
    
        return $this->_sendRequest('/friendship/cancel', $aParams, 'POST');
    }
}
