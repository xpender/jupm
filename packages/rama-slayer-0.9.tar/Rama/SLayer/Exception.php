<?php
/**
 * X-Rama
 *
 * SLayer Exception
 *
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 * @package net.bigpoint.rama.slayer
 */
class Rama_SLayer_Exception extends Rama_Exception
{
    const ERROR_SUB_CODE_DELIMITER = '.';

    private $_iErrorCode = null;

    public function __construct($sMessage, $iErrorCode, Exception $oPrevious = null)
    {
        $iCode = 0;

        $this->_iErrorCode = $iErrorCode;

        //check if we got sub error codes
        if (strpos($this->_iErrorCode, self::ERROR_SUB_CODE_DELIMITER) != false) {
            $aCodes = explode(self::ERROR_SUB_CODE_DELIMITER, $this->_iErrorCode);
            $iCode  = $aCodes[0];
        }

        if (version_compare(PHP_VERSION, '5.3.0', '<')) {
            parent::__construct($sMessage, (int)$iCode);
            $this->_previous = $oPrevious;
        } else {
            parent::__construct($sMessage, (int)$iCode, $oPrevious);
        }
    }

    /**
     * get complet errorcode including sub code
     * @return string
     */
    public function getErrorCode()
    {
        return $this->_iErrorCode;
    }
}
