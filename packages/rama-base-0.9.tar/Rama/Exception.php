<?php
class Rama_Exception extends Exception
{
}
