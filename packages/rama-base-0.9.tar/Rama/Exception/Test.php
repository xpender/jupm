<?php
class Rama_Exception_Test extends Rama_Exception
{
}
