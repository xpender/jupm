<?php
/**
 * X-Rama
 *
 * Rama registry (for easier dealing without using crazy singleton & static calls)
 *
 * @package net.bigpoint.rama
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 */
class Rama_Registry
{
    /**
     * Registry, to share objects between commands
     *
     * @var array
     */
    private $_aRegistry = array();

    /**
     * __construct
     *
     */
    /*public function __construct()
    {
    }*/

    /**
     * Returns something from registry
     *
     * @param string $sKey
     * @return mixed
     */
    public function get($sKey)
    {
        if (isset($this->_aRegistry[$sKey])) {
            return $this->_aRegistry[$sKey];
        }

        return false;
    }

    /**
     * Sets something into registry
     *
     * @param string $sKey
     * @param mixed $mValue
     */
    public function set($sKey, $mValue)
    {
        $this->_aRegistry[$sKey] = $mValue;
    }
}
