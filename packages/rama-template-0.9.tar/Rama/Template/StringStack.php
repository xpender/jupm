<?php
/**
 * X-Rama
 *
 * Replaces quoted strings in a text.
 * 
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_StringStack
{
    protected static $stringStack = array();
    
    /**
     * Replaces a string with an unique hash value.
     *
     * @param     string         $string
     * @param     string         $type
     * @return    string        $hash
     */
    public static function pushToStringStack($string, $type = 'default')
    {
        $hash = '@@'.Rama_Template_StringUtil::getHash(uniqid(microtime()).$string).'@@';
        
        if (!isset(self::$stringStack[$type])) {
            self::$stringStack[$type] = array();
        }
        
        self::$stringStack[$type][$hash] = $string;
        
        return $hash;
    }
    
    /**
     * Reinserts Strings that have been replaced by unique hash values.
     *
     * @param     string         $string
     * @param     string         $type
     * @return     string         $string
     */
    public static function reinsertStrings($string, $type = 'default')
    {
        if (isset(self::$stringStack[$type])) {
            foreach (self::$stringStack[$type] as $hash => $value) {
                if (Rama_Template_StringUtil::indexOf($string, $hash) !== false) {
                    $string = Rama_Template_StringUtil::replace($hash, $value, $string);
                    unset(self::$stringStack[$type][$hash]);
                }
            }
        }
        
        return $string;
    }
    
    /**
     * Returns the stack.
     *
     * @param     string        $type
     * @return    array
     */
    public static function getStack($type = 'default')
    {
        if (isset(self::$stringStack[$type])) {
            return self::$stringStack[$type];
        }
        
        return array();
    }
}