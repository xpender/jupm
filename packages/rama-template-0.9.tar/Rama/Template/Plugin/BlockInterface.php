<?php
/**
 * Block functions encloses a template block and operate on the contents of this block.
 * 
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
interface Rama_Template_Plugin_BlockInterface
{
    /**
     * Executes this template block.
     * 
     * @param    array            $tagArgs
     * @param    string            $blockContent
     * @param    Template         $tplObj
     * @return    string                    output
     */
    public function execute($tagArgs, $blockContent, Rama_Template $tplObj);
    
    /**
     * Initialises this template block.
     * 
     * @param    array            $tagArgs
     * @param    Template        $tplObj
     */
    public function init($tagArgs, Rama_Template $tplObj);
    
    /**
     * This function is called before every execution of this block function.
     * 
     * @param    Template        $tplObj
     * @return    boolean
     */
    public function next(Rama_Template $tplObj);
}
