<?php
/**
 * X-Rama
 *
 * The 'htmlcheckboxes' template function generates a list of html checkboxes.
 * 
 * Usage:
 * {htmlcheckboxes name="x" options=$array}
 * {htmlcheckboxes name="x" options=$array selected=$foo}
 * {htmlcheckboxes name="x" output=$outputArray}
 * {htmlcheckboxes name="x" output=$outputArray values=$valueArray}
 *
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Function_Htmlcheckboxes implements Rama_Template_Plugin_FunctionInterface
{
    protected $disableEncoding = false;
    
    /**
     * @see TemplatePluginFunction::execute()
     */
    public function execute($tagArgs, Rama_Template $tplObj)
    {
        // get options
        if (isset($tagArgs['output']) && is_array($tagArgs['output'])) {
            if (isset($tagArgs['values']) && is_array($tagArgs['values'])) {
                $tagArgs['options'] = array_combine($tagArgs['values'], $tagArgs['output']);
            } else {
                $tagArgs['options'] = array_combine($tagArgs['output'], $tagArgs['output']);
            }
        }

        if (!isset($tagArgs['options']) || !is_array($tagArgs['options'])) {
            throw new Rama_Template_Exception("missing 'options' argument in htmlCheckboxes tag", 12001);
        }
        
        if (!isset($tagArgs['name'])) {
            throw new Rama_Template_Exception("missing 'name' argument in htmlCheckboxes tag", 12001);
        }
        
        if (isset($tagArgs['disableEncoding']) && $tagArgs['disableEncoding']) {
            $this->disableEncoding = true;
        } else {
            $this->disableEncoding = false;
        }
        
        // get selected values
        if (isset($tagArgs['selected'])) {
            if (!is_array($tagArgs['selected'])) $tagArgs['selected'] = array($tagArgs['selected']);    
        } else {
            $tagArgs['selected'] = array();
        }
        if (!isset($tagArgs['separator'])) {
            $tagArgs['separator'] = '';
        }
        
        // build html
        $html = '';
        foreach ($tagArgs['options'] as $key => $value) {
            if (!empty($html)) $html .= $tagArgs['separator'];
            $html .= '<label><input type="checkbox" name="'.$this->encodeHTML($tagArgs['name']).'[]" value="'.$this->encodeHTML($key).'"'.(in_array($key, $tagArgs['selected']) ? ' checked="checked"' : '').' /> '.$this->encodeHTML($value).'</label>';    
        }
        
        return $html;
    }
    
    /**
     * Executes StringUtil::encodeHTML on the given text if disableEncoding is false.
     *
     * @see Rama_Template_StringUtil::encodeHTML()
     */
    protected function encodeHTML($text)
    {
        if (!$this->disableEncoding) {
            $text = Rama_Template_StringUtil::encodeHTML($text);
        }
        
        return $text;
    }
}
