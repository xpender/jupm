<?php
/**
 * affiliateBanner function, like the smarty one
 * supplied by the GameAPI
 *
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Function_Affiliatebanner implements Rama_Template_Plugin_FunctionInterface
{
    /**
     * @see Rama_Template_Plugin_FunctionInterface::execute()
     */
    public function execute ($tagArgs, Rama_Template $tplObj)
    {
        return Sky_GameApi::getInstance()->getBannerTag(
            (int)$tagArgs['zoneID'],
            $tagArgs['align'] ? $tagArgs['align'] : false,
            $tagArgs['valign'] ? $tagArgs['valign'] : false,
            $tagArgs['noframes'] ? true : false
            );
    }
}
