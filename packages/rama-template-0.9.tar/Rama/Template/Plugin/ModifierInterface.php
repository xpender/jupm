<?php
/**
 * X-Rama
 *
 * Modifiers are functions that are applied to a variable in the template 
 * before it is displayed or used in some other context.
 * 
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
interface Rama_Template_Plugin_ModifierInterface
{
    /**
     * Executes this modifier.
     * 
     * @param array $tagArgs        
     * @param Rama_Template $tplObj
     * @return string output        
     */
    public function execute($tagArgs, Rama_Template $tplObj);
}
