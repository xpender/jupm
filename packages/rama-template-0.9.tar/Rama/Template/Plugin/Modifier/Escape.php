<?php
/**
 * X-Rama
 *
 * Escpae modifier, mostly copied from smarty 2.6.26
 *
 * @author Monte Ohrt (original smarty version)
 * @author Marko Kercmar (Modifications)
 * @package net.bigpoint.rama.template
 */
class Rama_Template_plugin_Modifier_Escape implements Rama_Template_Plugin_ModifierInterface
{
    /**
     * @see Rama_Template_plugin_Modifier::execute()
     */
    public function execute($tagArgs, Rama_Template $tplObj)
    {
        switch ($tagArgs[1]) {
            case 'html':
                return htmlspecialchars($tagArgs[0], ENT_QUOTES, 'UTF-8');

            case 'htmlall':
                return htmlentities($tagArgs[0], ENT_QUOTES, 'UTF-8');

            case 'url':
                return rawurlencode($tagArgs[0]);

            case 'quotes':
                // escape unescaped single quotes
                return preg_replace("%(?<!\\\\)'%", "\\'", $tagArgs[0]);

            case 'javascript':
                // escape quotes and backslashes, newlines, etc.
                return  strtr($string, array('\\'=>'\\\\',"'"=>"\\'",'"'=>'\\"',"\r"=>'\\r',"\n"=>'\\n','</'=>'<\/'));

            default:
                return $tagArgs[0];
        }
    }
}
