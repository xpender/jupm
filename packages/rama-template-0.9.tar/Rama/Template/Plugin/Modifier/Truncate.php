<?php
/**
 * X-Rama
 *
 * The 'truncate' modifier truncates a string.
 * 
 * Usage:
 * {$foo|truncate:35:'...'}
 *
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Modifier_Truncate implements Rama_Template_Plugin_ModifierInterface
{
    /**
     * @see TemplatePluginModifier::execute()
     */
    public function execute($tagArgs, Rama_Template $tplObj)
    {
        // default values
        $length = 80;
        $etc = '...';
        $breakWords = false;
        
        // get values
        $string = $tagArgs[0];
        if (isset($tagArgs[1])) $length = intval($tagArgs[1]);
        if (isset($tagArgs[2])) $etc = $tagArgs[2];
        if (isset($tagArgs[3])) $breakWords = $tagArgs[3];
        
        // execute plugin
        if ($length == 0) {
            return '';
        }

        if (Rama_Template_StringUtil::length($string) > $length) {
            $length -= Rama_Template_StringUtil::length($etc);
            
            if (!$breakWords) {
                $string = preg_replace('/\s+?(\S+)?$/', '', Rama_Template_StringUtil::substring($string, 0, $length + 1));
            }
  
            return Rama_Template_StringUtil::substring($string, 0, $length).$etc;
        } else {
               return $string;
        }
    }
}
