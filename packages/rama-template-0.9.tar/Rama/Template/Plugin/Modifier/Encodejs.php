<?php
/**
 * X-Rama
 *
 * The 'encodejs' modifier formats a string for usage in a single quoted javascript string. 
 * Escapes single quotes and new lines.
 * 
 * Usage:
 * {$string|encodejs}
 * {"bl''ah"|encodejs}
 *
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Modifier_Encodejs implements Rama_Template_Plugin_ModifierInterface
{
    /**
     * @see TemplatePluginModifier::execute()
     */
    public function execute($tagArgs, Rama_Template $tplObj)
    {
        // escape backslash
        $tagArgs[0] = Rama_Template_StringUtil::replace("\\", "\\\\", $tagArgs[0]);
        
        // escape singe quote
        $tagArgs[0] = Rama_Template_StringUtil::replace("'", "\'", $tagArgs[0]);
        
        // escape new lines
        $tagArgs[0] = Rama_Template_StringUtil::replace("\n", '\n', $tagArgs[0]);
        
        // escape slashes
        $tagArgs[0] = Rama_Template_StringUtil::replace("/", '\/', $tagArgs[0]);
        
        return $tagArgs[0];
    }
}
