<?php
/**
 * X-Rama
 *
 * The 'concat' modifier returns the string that results from concatenating the arguments.
 * May have two or more arguments.
 * 
 * Usage:
 * {"left"|concat:$right}
 *
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Modifier_Concat implements Rama_Template_Plugin_ModifierInterface
{
    /**
     * @see TemplatePluginModifier::execute()
     */
    public function execute($tagArgs, Rama_Template $tplObj)
    {
        if (count($tagArgs) < 2) {
            throw new Rama_Template_Exception("concat modifier needs two or more arguments", 12001);
        }
        
        $result = '';
        foreach ($tagArgs as $arg) {
            $result .= $arg;
        }
    
        return $result;    
    }
}
