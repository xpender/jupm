<?php
/**
 * X-Rama
 *
 * The 'fetch' compiler function fetches files from the local file system, http, or ftp and displays the content.
 * 
 * Usage:
 * {fetch file='x.html'}
 * {fetch file='x.html' assign=var}
 * 
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Compiler_Fetch implements Rama_Template_Plugin_CompilerInterface
{
    /**
     * @see TemplatePluginCompiler::executeStart()
     */
    public function executeStart($tagArgs, Rama_Template_ScriptingCompiler $compiler)
    {
        if (!isset($tagArgs['file'])) {
            throw new Rama_Template_Exception(
                $compiler->formatSyntaxError("missing 'file' argument in fetch tag", $compiler->getCurrentIdentifier(), $compiler->getCurrentLineNo())
                );
        }
        
        if (isset($tagArgs['assign'])) {
            return "<?php \$this->assign(".$tagArgs['assign'].", @file_get_contents(".$tagArgs['file'].")); ?>";
        } else {
            return "<?php echo @file_get_contents(".$tagArgs['file']."); ?>";
        }
    }
    
    /**
     * @see TemplatePluginCompiler::executeEnd()
     */
    public function executeEnd(Rama_Template_ScriptingCompiler $compiler)
    {
        throw new Rama_Template_Exception(
            $compiler->formatSyntaxError("unknown tag {/fetch}", $compiler->getCurrentIdentifier(), $compiler->getCurrentLineNo())
            );
    }
}
