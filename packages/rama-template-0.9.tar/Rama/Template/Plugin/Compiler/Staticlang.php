<?php
/**
 * X-Rama
 *
 * The 'staticlang' compiler function gets the source of a language variables.
 * 
 * Usage:
 * {staticlang}$blah{/staticlang}
 *
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Compiler_Staticlang implements Rama_Template_Plugin_CompilerInterface
{
    /**
     * @see TemplatePluginCompiler::executeStart()
     */
    public function executeStart($tagArgs, Rama_Template_ScriptingCompiler $compiler)
    {
        $compiler->pushTag('staticlang');
        
        return "<?php ob_start(); ?>";
    }
    
    /**
     * @see TemplatePluginCompiler::executeEnd()
     */
    public function executeEnd(Rama_Template_ScriptingCompiler $compiler)
    {
        $compiler->popTag('staticlang');
        $hash = Rama_Template_StringUtil::getRandomID();
        return "<?php \$_lang".$hash." = ob_get_contents(); ob_end_clean(); echo $this->getLanguage()->get(\$_lang".$hash."); ?>";
    }
}
