<?php
/**
 * X-Rama
 *
 * The 'lang' compiler function compiles dynamic language variables.
 * 
 * Usage:
 * {lang}$blah{/lang}
 * {lang var=$x}foo{/lang}
 *
 * @author Marcel Werk
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Compiler_Langjs implements Rama_Template_Plugin_CompilerInterface
{
    /**
     * @see TemplatePluginCompiler::executeStart()
     */
    public function executeStart($tagArgs, Rama_Template_ScriptingCompiler $compiler)
    {
        $compiler->pushTag('langjs');
        
        $newTagArgs = array();
        foreach ($tagArgs as $key => $arg) {
            $newTagArgs[$key] = 'StringUtil::encodeHTML('.$arg.')';
        }
        
        $tagArgs = $compiler->makeArgString($newTagArgs);
        return "<?php \$this->tagStack[] = array('langjs', array($tagArgs)); ob_start(); ?>";
    }
    
    /**
     * @see TemplatePluginCompiler::executeEnd()
     */
    public function executeEnd(Rama_Template_ScriptingCompiler $compiler)
    {
        $compiler->popTag('langjs');
        $hash = Rama_Template_StringUtil::getRandomID();
        return "<?php \$_lang".$hash." = ob_get_contents(); ob_end_clean(); echo str_replace(\"'\", \"\'\", \$this->getLanguage()->getDynamicVariable(\$_lang".$hash.", \$this->tagStack[count(\$this->tagStack) - 1][1], \$this)); array_pop(\$this->tagStack); ?>";
    }
}
