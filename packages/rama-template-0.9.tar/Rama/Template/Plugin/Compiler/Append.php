<?php
/**
 * X-Rama
 *
 * The 'append' compiler function calls the append function on the template object.
 * 
 * Usage:
 * {append var=name value="foo"}
 *
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Compiler_Append implements Rama_Template_Plugin_CompilerInterface
{
    /**
     * @see TemplatePluginCompiler::executeStart()
     */
    public function executeStart($tagArgs, Rama_Template_ScriptingCompiler $compiler)
    {
        if (!isset($tagArgs['var'])) {
            throw new Rama_Template_Exception(
                $compiler->formatSyntaxError("missing 'var' argument in append tag", $compiler->getCurrentIdentifier(), $compiler->getCurrentLineNo())
                );
        }
        if (!isset($tagArgs['value'])) {
            throw new Rama_Template_Exception(
                $compiler->formatSyntaxError("missing 'value' argument in append tag", $compiler->getCurrentIdentifier(), $compiler->getCurrentLineNo())
                );
        }
                
        return "<?php \$this->append(".$tagArgs['var'].", ".$tagArgs['value']."); ?>";
    }
    
    /**
     * @see TemplatePluginCompiler::executeEnd()
     */
    public function executeEnd(Rama_Template_ScriptingCompiler $compiler) {
        throw new Rama_Template_Exception(
            $compiler->formatSyntaxError("unknown tag {/append}", $compiler->getCurrentIdentifier(), $compiler->getCurrentLineNo())
            );
    }
}
