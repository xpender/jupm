<?php
/**
 * X-Rama
 *
 * Compiler functions are called during the compilation of a template.
 *
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications);
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
interface Rama_Template_Plugin_CompilerInterface
{
    /**
     * Executes the start tag of this compiler function.
     * 
     * @param    array                $tagArgs        
     * @param    TemplateScriptingCompiler    $compiler
     * @return    string                        php code    
     */
    public function executeStart($tagArgs, Rama_Template_ScriptingCompiler $compiler);
    
    /**
     * Executes the end tag of this compiler function.
     * 
     * @param    TemplateScriptingCompiler    $compiler    
     * @return    string                        php code    
     */
    public function executeEnd(Rama_Template_ScriptingCompiler $tplObj);
}
