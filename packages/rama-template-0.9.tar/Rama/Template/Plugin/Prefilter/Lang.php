<?php
/**
 * X-Rama
 *
 * The 'lang' prefilter compiles static language variables.
 * Dynamic language variables will catched by the 'lang' compiler function.
 * It is recommended to use static language variables.
 * 
 * Usage:
 * {lang}foo{/lang}
 * {lang}lang.foo.bar{/lang}
 *
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Prefilter_Lang implements Rama_Template_Plugin_PrefilterInterface
{
    /**
     * @see TemplatePluginPrefilter::execute()
     */
    public function execute($sourceContent, Rama_Template_ScriptingCompiler $compiler)
    {
        $ldq = preg_quote($compiler->getLeftDelimiter(), '~');
        $rdq = preg_quote($compiler->getRightDelimiter(), '~');
        $sourceContent = preg_replace("~{$ldq}lang{$rdq}([\w\.]+){$ldq}/lang{$rdq}~e", '$compiler->getTemplate()->getLanguage()->get(\'$1\')', $sourceContent);

        return $sourceContent;
    }
}
