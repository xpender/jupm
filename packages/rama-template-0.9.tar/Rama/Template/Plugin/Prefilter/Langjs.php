<?php
/**
 * X-Rama
 *
 * The 'langjs' prefilter compiles static language variables and adds slashes before '
 * Dynamic language variables will catched by the 'langjs' compiler function.
 * It is recommended to use static language variables.
 * 
 * Usage:
 * {langjs}foo{/langjs}
 * {langjs}lang.foo.bar{/langjs}
 *
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Plugin_Prefilter_Langjs implements Rama_Template_Plugin_PrefilterInterface
{
    /**
     * @see TemplatePluginPrefilter::execute()
     */
    public function execute($sourceContent, Rama_Template_ScriptingCompiler $compiler)
    {
        $ldq = preg_quote($compiler->getLeftDelimiter(), '~');
        $rdq = preg_quote($compiler->getRightDelimiter(), '~');
        $sourceContent = preg_replace("~{$ldq}langjs{$rdq}([\w\.]+){$ldq}/langjs{$rdq}~e", 'str_replace("\'", "' . "\'" . '", $compiler->getTemplate()->getLanguage()->get(\'$1\'));', $sourceContent);

        return $sourceContent;
    }
}
