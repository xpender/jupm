<?php
/**
 * X-Rama
 *
 * Template functions are identical to template blocks, but they have no closing tag.
 * 
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
interface Rama_Template_Plugin_FunctionInterface
{
    /**
     * Executes this template function.
     * 
     * @param    array            $tagArgs
     * @param    Template        $tplObj
     * @return    string                    output
     */
    public function execute($tagArgs, Rama_Template $tplObj);
}
