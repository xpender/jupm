<?php
/**
 * X-Rama
 *
 * Template system exception class
 *
 * @author Marko Kercmar
 * @package net.bigpoint.rama.template
 */
class Rama_Template_Exception extends Rama_Exception
{
}
