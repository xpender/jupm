<?php
/**
 * X-Rama
 *
 * Template loads and displays template.
 * 
 * @author Marcel Werk
 * @author Marko Kercmar (Modifications)
 * @copyright 2001-2009 WoltLab GmbH
 * @license GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package net.bigpoint.rama.template
 */
class Rama_Template
{
    /**
     * fake reference on $this, needed by GameAPI
     *
     * @var Rama_Template
     */
    public $smarty;

    /**
     * Hooks
     *
     * @var array
     */
    protected $_aHooks;

    /**
     * Template path
     *
     * @var string
     */
    protected $_sTemplatePath;

    /**
     * Instance of language obj
     *
     * @var Rama_LanguageAbstract
     */
    protected $_oLanguage;

    /**
     * Compile dir
     *
     * @var string
     */
    protected $_sCompileDir;

    protected $forceCompile = false;
    protected $prefilters = array();
    protected $compilerObj = '';
    protected $v = array();
    protected $cachePrefix = '';
    
    /**
     * Creates a new Template object.
     *
     * @param string $sTemplatePath
     * @param Rama_LanguageAbstract $oLanguage
     * @param string $sCompileDir (optional - will be autodetected on bigpoint systems)
     * @return Rama_Template
     */
    public function __construct($sTemplatePath, Rama_LanguageAbstract $oLanguage, $sCompileDir = null, $bForceCompile = false)
    {
        $this->setTemplatePath($sTemplatePath);
        $this->setLanguage($oLanguage);

        if (null === $sCompileDir) {
            $sCompileDir = getTmpDir(
                'smarty/'
              . md5($this->_sTemplatePath . $this->_oLanguage->getLocale())
              );
        }

        $this->setCompileDir($sCompileDir);

        $this->forceCompile = $bForceCompile;

        // assign default stuff
        $this->assignSystemVariables();

        // register default prefilter
        $this->registerPrefilter('lang');
        $this->registerPrefilter('langjs');

        // fake reference for gameapi
        $this->smarty =& $this;
    }
    
    /**
     * Assigns some system variables.
     */
    protected function assignSystemVariables()
    {
        $this->v['tpl'] = array();

        // assign session
        $this->v['tpl']['sid'] = session_id();
        
        // assign super globals
        $this->v['tpl']['get'] =& $_GET;
        $this->v['tpl']['post'] =& $_POST;
        $this->v['tpl']['cookie'] =& $_COOKIE;
        $this->v['tpl']['server'] =& $_SERVER;
        $this->v['tpl']['env'] =& $_ENV;
        
        // system info
        $this->v['tpl']['now'] = time();
        $this->v['tpl']['template'] = '';
        $this->v['tpl']['includedTemplates'] = array();
        
        // section / foreach / capture arrays
        $this->v['tpl']['section'] = $this->v['tpl']['foreach'] = $this->v['tpl']['capture'] = array();
    }
    
    /**
     * Sets the dir for the compiled templates.
     *
     * @param string $sCompileDir
     */
    public function setCompileDir($sCompileDir)
    {
        if (false === is_dir($sCompileDir)) {
            throw new Rama_Template_Exception(
                "'". $sCompileDir . '\' is not a valid dir'
                );
        }
        
        if (substr($sCompileDir, -1) != '/') {
            $sCompileDir .= '/';
        }
        
        $this->_sCompileDir = $sCompileDir;
    }

    /**
     * set the path to template sources.
     *
     * @param string $sTemplatePath
     */
    public function setTemplatePath($sTemplatePath)
    {
        if (false === is_dir($sTemplatePath)) {
            throw new Rama_Template_Exception(
                "'". $sTemplatePath . '\' is not a valid dir'
                );
        }

        if (substr($sTemplatePath, -1) != '/') {
            $sTemplatePath .= '/';
        }

        $this->_sTemplatePath = $sTemplatePath;
    }

    /**
     * set a instance of Rama_Language to use
     *
     * @param Rama_LanguageAbstract $oLanguage
     */
    public function setLanguage(Rama_LanguageAbstract $oLanguage)
    {
        $this->_oLanguage = $oLanguage;
    }

    /**
     * returns the language instance
     *
     * @return Rama_LanguageAbstract
     */
    public function getLanguage()
    {
        return $this->_oLanguage;
    }
    
    /**
     * Returns the current path to the template sources.
     *
     * @return string $sTemplatePath
     */
    public function getTemplatePath()
    {
        return $this->_sTemplatePath;
    }
    
    /**
     * Returns the current compile dir
     *
     * @eturn string $sCompileDir
     */
    public function getCompileDir()
    {
        return $this->_sCompileDir;
    }
    
    /**
     * Assigns a template variable.
     *
     * @param     mixed         $variable
     * @param     mixed         $value
     */
    public function assign($variable, $value = '')
    {
        if (is_array($variable)) {
            foreach ($variable as $key => $val) {
                if ($key != '') {
                    $this->assign($key, $val);
                }
            }
        }
        else {
            if (!empty($variable)) {
                $this->v[$variable] = $value;
            }
        }
    }
    
    /**
     * Appends content to an existing template variable.
     *
     * @param     mixed         $variable
     * @param     mixed         $value
     */
    public function append($variable, $value = '')
    {
        if (is_array($variable)) {
            foreach ($variable as $key => $val) {
                if ($key != '') {
                    $this->append($key, $val);
                }
            }
        }
        else {
            if (!empty($variable)) {
                if (isset($this->v[$variable])) {
                    if (is_array($this->v[$variable]) && is_array($value)) {
                        $keys = array_keys($value);
                        foreach ($keys as $key) {
                            if (isset($this->v[$variable][$key])) {
                                $this->v[$variable][$key] .= $value[$key];
                            }
                            else { 
                                $this->v[$variable][$key] = $value[$key];
                            }
                        }
                    }
                    else {
                        $this->v[$variable] .= $value;
                    }
                }
                else {
                    $this->v[$variable] = $value;
                }
            }
        }
    }
    
    /**
     * Assigns a template variable by reference.
     *
     * @param     string         $variable
     * @param    mixed         $value
     */
    public function assignByRef($variable, &$value)
    {
        if (!empty($variable)) {
            $this->v[$variable] = &$value;
        }
    }

    /**
     * @depracted use assignbyRef instead
     */
    public function assignRef($variable, &$value)
    {
        return $this->assignByRef($variable, &$value);
    }
    
    /**
     * Clears an assignment of a template variable.
     *
     * @param     mixed         $variable
     */
    public function clearAssign($variable)
    {
        if (is_array($variable)) {
            foreach ($variable as $val) {
                unset($this->v[$val]);
            }
        }
        else {
            unset($this->v[$variable]);
        }
    }
    
    /**
     * Clears assignment of all template variables.
     */
    public function clearAllAssign() 
    {
        $this->v = array();
    }
    
    /**
     * Outputs a template.
     *
     * @param    string        $templateName
     */
    public function display($templateName, $bHooking = true)
    {
        $compiledFilename = $this->getCompiledFilename($templateName);
        $sourceFilename = $this->getSourceFilename($templateName);

        // check if compilation is necessary
        if (!$this->isCompiled($sourceFilename, $compiledFilename)) {
            // compile
            $this->compileTemplate($templateName, $sourceFilename, $compiledFilename);
        }

        if ($bHooking) {
            $this->_callHooks('display.start', $this, $templateName);
        }
        
        include($compiledFilename);
        
        if ($bHooking) {
            $this->_callHooks('display.end', $this, $templateName);
        }
    }
    
    /**
     * Returns the absolute filename of a compiled template.
     *
     * @param     string         $templateName
     * @param     integer     $packageID
     * @return     string         $path
     */
    public function getCompiledFilename($sTemplateName)
    {
        return $this->_sCompileDir . $this->_oLanguage->getLocale() . '_' . str_replace('/', '_', $sTemplateName) . '.php';
    }

    public function sourceFileExists($sTemplateName)
    {
        // fix suffix
        if (strpos($sTemplateName, '.tpl') !== false) {
            $sTemplateName = str_replace('.tpl', '', $sTemplateName);
        }

        $sFilePath = $this->_sTemplatePath . $sTemplateName . '.tpl';

        if (file_exists($sFilePath)) {
            return true;
        }

        return false;
    }
    
    /**
     * Returns the absolute filename of a template source.
     *
     * @param    string        $templateName
     * @return    string        $path
     */
    public function getSourceFilename($sTemplateName)
    {
        // fix suffix
        if (strpos($sTemplateName, '.tpl') !== false) {
            $sTemplateName = str_replace('.tpl', '', $sTemplateName);
        }

        $sFilePath = $this->_sTemplatePath . $sTemplateName . '.tpl';

        if (file_exists($sFilePath)) {
            return $sFilePath;
        }

        throw new Rama_Template_Exception(
            'Unable to find template \'' . $sTemplateName . "'"
            );
    }
    
    /**
     * Checks wheater a template is already compiled or not.
     *
     * @param     string         $sourceFilename
     * @param     string         $compiledFilename
     * @return     boolean     $isCompiled
     */
    protected function isCompiled($sourceFilename, $compiledFilename)
    {
        if ($this->forceCompile || !file_exists($compiledFilename)) {
            return false;
        }
        else {
            $sourceMTime = @filemtime($sourceFilename);
            $compileMTime = @filemtime($compiledFilename);

            return !($sourceMTime >= $compileMTime);
        }
    }
    
    /**
     * Compiles a template.
     *
     * @param     string         $templateName
     * @param     string         $sourceFilename
     * @param     string         $compiledFilename
     */
    protected function compileTemplate($templateName, $sourceFilename, $compiledFilename)
    {
        // get compiler
        if (!is_object($this->compilerObj)) {
            $this->compilerObj = $this->getCompiler();
        }
        
        // get source
        $sourceContent = $this->getSourceContent($sourceFilename);
        
        // compile template
        $this->compilerObj->compile($templateName, $sourceContent, $compiledFilename);
    }
    
    /**
     * Returns a new template compiler object.
     * 
     * @return    TemplateCompiler
     */
    protected function getCompiler()
    {
        return new Rama_Template_Compiler($this);
    }
    
    /**
     * Reads the content of a template file.
     *
     * @param    string        $sourceFilename
     * @return    string        $sourceContent
     */
    public function getSourceContent($sourceFilename)
    {
        $sourceContent = '';
        if (!file_exists($sourceFilename) || (($sourceContent = @file_get_contents($sourceFilename)) === false)) {
            throw new Rama_Template_Exception("Could not open template '$sourceFilename' for reading", 12005);
        }
        else {
            return $sourceContent;
        }
    }
    
    /**
     * Returns the output of a template.
     *
     * @param     string         $templateName
     * @return     string         output
     */
    public function fetch($templateName)
    {
        ob_start();
        $this->display($templateName, false);
        $output = ob_get_contents();
        ob_end_clean();

        return $output;
    }
    
    /**
     * Executes a compiled template scripting source and returns the result.
     *
     * @param     string         $compiledSource
     * @return     string         result
     */
    public function fetchString($compiledSource)
    {
        ob_start();
        eval('?>'.$compiledSource);
        $output = ob_get_contents();
        ob_end_clean();

        return $output;
    }
    
    /**
     * Includes a template.
     *
     * @param     string         $templateName
     * @param     array         $variables
     * @param     boolean        $sandbox    enables execution in sandbox
     */
    protected function includeTemplate($templateName, $variables = array(), $sandbox = true)
    {
        // add new template variables
        if ($sandbox) {
            $templateVars = $this->v;
        }

        if (count($variables)) {
            $this->v = array_merge($this->v, $variables);
        }
        
        $this->display($templateName, false);
        
        if ($sandbox) {
            $this->v = $templateVars;
        }
    }

    /**
     * Returns the filename of a plugin.
     *
     * @param string $type
     * @param string $tag
     * @return string filename
     */
    public function getPluginFilename($type, $tag)
    {
        $sClassName = 'Rama_Template_Plugin_' . ucfirst(strtolower($type)) . '_' . ucfirst(strtolower($tag));

        return SysConfig::getProjectRoot() . '/include/' . str_replace('_', DIRECTORY_SEPARATOR, $sClassName) . '.php';
    }
    
    /**
     * Returns an array with all prefilters.
     *
     * @return     array
     */
    public function getPrefilters()
    {
        return $this->prefilters;
    }
    
    /**
     * Registers a prefilter.
     * This method accepts a single prefilter name
     * or an array of prefilters.
     *
     * @param     mixed         $name
     */
    public function registerPrefilter($name)
    {
        if (is_array($name)) {
            foreach ($name as $val) {
                $this->registerPrefilter($val);
            }
        }
        else {
            $this->prefilters[$name] = $name;
        }
    }
    
    /**
     * Returns the value of a template variable.
     * 
     * @param     string        $varname
     * @return    mixed
     */
    public function get($varname)
    {
        if (isset($this->v[$varname])) {
            return $this->v[$varname];
        }
        
        return null;
    }
    
    /**
     * Deletes all compiled templates.
     * 
     * @param     string        $compileDir
     */
    public static function deleteCompiledTemplates($compileDir = '')
    {
        if (empty($compileDir)) $compileDir = WCF_DIR.'templates/compiled/';
        
        // delete compiled templates
        $matches = glob($compileDir . '*_*_*.php');
        if (is_array($matches)) {
            foreach ($matches as $match) @unlink($match);
        }
    }

    /**
     * Adds a hook
     *
     * @param string $sHookType (Valid: display.start & display.end)
     * @param callback $mCallback
     */
    public function addHook($sHookType, $mCallback)
    {
        if ($sHookType == 'showTemplate.start') {
            $sHookType = 'display.start';
        } elseif ($sHookType == 'showTemplate.end') {
            $sHookType = 'display.end';
        }

        if ($sHookType != 'display.start' && $sHookType != 'display.end') {
            throw new Rama_Template_Exception(
                'Invalid hook type given'
                );
        }

        if (false === is_callable($mCallback)) {
            throw new Rama_Template_Exception(
                'Given hook is not callable'
                );
        }

        $this->_aHooks[$sHookType][] = $mCallback;
    }

    /**
     * Calls the registered hooks
     *
     * @param string $sHookType
     */
    protected function _callHooks($sHookType)
    {
        $aExtArgs = array_slice(func_get_args(), 1);

        if (isset($this->_aHooks[$sHookType]) && is_array($this->_aHooks[$sHookType])) {
            foreach ($this->_aHooks[$sHookType] as $cHook) {
                call_user_func_array($cHook, $aExtArgs);
            }
        }
    }

    /**
     * Compat for gameapi..
     */
    public function register_function()
    {
    }
}
