<?php
/**
 * X-Rama
 *
 * @package net.bigpoint.rama.cache
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 */
interface Rama_CacheBuilderInterface
{
    public static function build(array $aArgs, Zend_Db_Adapter_Abstract $oDb);
}
