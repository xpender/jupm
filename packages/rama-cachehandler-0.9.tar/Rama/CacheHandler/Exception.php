<?php
/**
 * X-Rama
 *
 * CacheHandler exception class
 *
 * @package net.bigpoint.rama.cache
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 */
class Rama_CacheHandler_Exception extends Rama_Exception
{
}
