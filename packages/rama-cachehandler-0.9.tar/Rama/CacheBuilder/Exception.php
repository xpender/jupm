<?php
/**
 * X-Rama
 *
 * CacheBuilder exception
 *
 * @package net.bigpoint.rama.cache
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 */
class Rama_CacheBuilder_Exception extends Rama_Exception
{
}
