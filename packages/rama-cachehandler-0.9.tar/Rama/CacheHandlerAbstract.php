<?php
/**
 * X-Rama
 *
 * Cache Handler
 *
 * @package net.bigpoint.rama.cache
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 */
abstract class Rama_CacheHandlerAbstract
{
    const DB_SYSTEM  = 0;
    const DB_USER    = 1;

    /**
     * Contains the registered caches
     *
     * @var array
     */
    private $_aCacheResources = array();

    /**
     * Containst the cas values of keys
     *
     * @var array
     */
    private $_aCas = array();

    /**
     * Registers a new cache, if already known - it does nothing
     *
     * @param string $sCacheName unique identifier of this cache
     * @param string $sClassName class name of the cachebuilder
     * @param array $aArgs arguments passed to the cachebuilder
     * @param int $iLifetime lifetime of the cache
     * @param int $iDbType db type (should be Rama_CacheHandler::DB_SYSTEM oder Rama_CacheHandler::DB_USER const)
     * @param int $iDbMcIdentifier
     * @void
     */
    public function addResource($sCacheName, $sClassName, array $aArgs,
        $iLifetime, $iDbType, $iDbMcIdentifier)
    {
        if (isset($this->_aCacheResources[$sCacheName])) {
            return;
        }

        if ($iDbType !== self::DB_SYSTEM && $iDbType !== self::DB_USER) {
            throw new Rama_CacheHandler_Exception(
                __METHOD__ . ' - unknown db type given'
                );
        }

        $this->_aCacheResources[$sCacheName] = array(
            'cacheName' => $sCacheName,
            'key' => $this->_getEscapedCacheKey($sCacheName, $iDbType, $iDbMcIdentifier),
            'className' => $sClassName,
            'args' => $aArgs,
            'lifeTime' => $iLifetime,
            'dbType' => $iDbType,
            'dbMcIdentifier' => $iDbMcIdentifier,
            'data' => null
            );
    }

    /**
     * Returns a escaped cache key for use at memcache
     *
     * @param string $sCacheName
     * @return string
     */
    protected function _getEscapedCacheKey($sCacheName)
    {
        return str_replace(array("'", '"', ' ', '`', '´', "\x00"), '_', $sCacheName);
    }
    
    /**
     * Returns a instance of the system memcache
     *
     * @param string $sIpAddress
     * @return Rama_Memcache
     */
    abstract protected function &_getSystemMemcache();

    /**
     * Returns a instance of the system db connection
     *
     * @return Zend_Db_Adapter_Abstract
     */
    abstract protected function &_getSystemDb();

    /**
     * Returns a instance of the specified user memcache
     *
     * @param int $iUserId UserId of user
     * @return Rama_Memcache
     */
    abstract protected function &_getUserMemcache($iUserId);

    /**
     * Returns a instance of the speicified user database connection
     *
     * @param int $iUserId UserId of user
     * @return Zend_Db_Adapter_Abstract
     */
    abstract protected function &_getUserDb($iUserId);

    abstract protected function _getCacheVersion();

    /**
     * Deletes a cache in the memcache.
     * If known and loaded, it will be automatically rebuilded
     * (So if you used a reference, you will automatically get the new cache content)
     *
     * If not registered, it tryes to delete the cache key on every memcache
     *
     * @param string $sCacheName unique cache identifier
     * @void
     */
    public function clear($sCacheName)
    {
        if (!isset($this->_aCacheResources[$sCacheName])) {
            throw new Rama_CacheHandler_Exception(
                'CacheHandler::clear - can not clear unrecongnized cache: ' . $sCacheName
                );
        }

        // Cache is registered, we know it memcache key
        $sCacheKey = $this->_aCacheResources[$sCacheName]['key'];

        $iDbMcIdentifier = $this->_aCacheResources[$sCacheName]['dbMcIdentifier'];

        if ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_SYSTEM) {
            $this->_getSystemMemcache()->delete($sCacheKey);
        } elseif ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_USER) {
            $this->_getUserMemcache($iDbMcIdentifier)->delete($sCacheKey);
        } else {
            throw new Rama_CacheHandler_Exception(
                __METHOD__ . ' - unkown dbType'
                );
        }

        if (null !== $this->_aCacheResources[$sCacheName]['data']) {
            $this->_build($sCacheName);
        }
    }

    /**
     * Loads a cache from memcache or if not available at memcache
     * it will be rebuilded using the cachebuilder
     *
     * @param string $sCacheName unique cache identifier
     * @return mixed
     */
    public function &load($sCacheName)
    {
        if (!isset($this->_aCacheResources[$sCacheName])) {
            throw new Rama_CacheHandler_Exception(
                'CacheHandler::load - can not load unrecongnized cache: ' . $sCacheName
                );
        }

        // if not loaded, load it from memcache if possible, other rebuild it
        if (null === $this->_aCacheResources[$sCacheName]['data']) {
            $iLifetime = $this->_aCacheResoureces[$sCacheName]['lifeTime'];
            
            $iDbMcIdentifier = $this->_aCacheResources[$sCacheName]['dbMcIdentifier'];

            if ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_SYSTEM) {
                $mResult = $this->_getSystemMemcache()->getCas($this->_aCacheResources[$sCacheName]['key'], $iCas);
            } elseif ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_USER) {
                $mResult = $this->_getUserMemcache($iDbMcIdentifier)->getCas($this->_aCacheResources[$sCacheName]['key'], $iCas);
            } else {
                throw new Rama_CacheHandler_Exception(
                    __METHOD__ . ' - unkown dbType'
                    );
            }

            $bValid = true;

            if (!is_array($mResult)) {
                $bValid = false;
            } elseif (($mResult['buildTime'] + $mResult['lifeTime']) < time()) {
                $bValid = false;
            } elseif ($mResult['cacheVersion'] != $this->_getCacheVersion()) {
                $bValid = false;
            }

            if (!$bValid) {
                $this->_build($sCacheName);
            } else {
                $this->_aCas[$this->_aCacheResources[$sCacheName]['key']] = $iCas;
                $this->_aCacheResources[$sCacheName]['data'] = $mResult['data'];
            }
        }

        return $this->_aCacheResources[$sCacheName]['data'];
    }

    /**
     * Sets back the cache to memcache, instead of clear and load it from database
     *
     * @param string $sCacheName
     * @param mixed $mData
     * @void
     */
    public function set($sCacheName, &$mData)
    {
        if (!isset($this->_aCacheResources[$sCacheName])) {
            throw new Rama_CacheHandler_Exception(
                'CacheHandler::set - can not set unrecongnized cache: ' . $sCacheName
                );
        }

        $this->_aCacheResources[$sCacheName]['data'] =& $mData;
        
        $iDbMcIdentifier = $this->_aCacheResources[$sCacheName]['dbMcIdentifier'];
        
        if ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_SYSTEM) {
            $oMemcache = $this->_getSystemMemcache();
        } elseif ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_USER) {
            $oMemcache = $this->_getUserMemcache($iDbMcIdentifier);
        } else {
            throw new Rama_CacheHandler_Exception(
                __METHOD__ . ' - unkown dbType'
                );
        }

        $oMemcache->set(
            $this->_aCacheResources[$sCacheName]['key'],
            array(
                'buildTime'    => time(),
                'lifeTime'     => $this->_aCacheResources[$sCacheName]['lifeTime'],
                'cacheVersion' => $this->_getCacheVersion(),
                'data'         => $this->_aCacheResources[$sCacheName]['data'],
                 ),
            $this->_aCacheResources[$sCacheName]['lifeTime']
            );
    }

    /**
     * Updates cache in memcache, but checks the cas value
     *
     * @param string $sCacheName
     * @param mixed $mData
     * @void
     */
    public function update($sCacheName, &$mData)
    {
        if (!isset($this->_aCacheResources[$sCacheName])) {
            throw new Rama_CacheHandler_Exception(
                __METHOD__ . ' - can not update unrecongnized cache: ' . $sCacheName
                );
        }
        
        $this->_aCacheResources[$sCacheName]['data'] =& $mData;
        
        $iDbMcIdentifier = $this->_aCacheResources[$sCacheName]['dbMcIdentifier'];
        
        if ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_SYSTEM) {
            $oMemcache = $this->_getSystemMemcache();
        } elseif ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_USER) {
            $oMemcache = $this->_getUserMemcache($iDbMcIdentifier);
        } else {
            throw new Rama_CacheHandler_Exception(
                __METHOD__ . ' - unknown dbType'
                );
        }

        $sKey = $this->_aCacheResources[$sCacheName]['key'];

        $bResult = $oMemcache->cas(
            $this->_aCas[$sKey],
            $sKey,
            array(
                'buildTime'    => time(),
                'lifeTime'     => $this->_aCacheResources[$sCacheName]['lifeTime'],
                'cacheVersion' => $this->_getCacheVersion(),
                'data'         => $this->_aCacheResources[$sCacheName]['data']
                ),
            $this->_aCacheResources[$sCacheName]['lifeTime']
            );

        if (!$bResult || isset($bResult['error'])) {
            $this->clear($sCacheName);
        }
    }

    /**
     * Rebuilds a cache using the cachebuilder from database
     *
     * @param string $sCacheName unique cache identifier
     * @void
     */
    private function _build($sCacheName)
    {
        if (!isset($this->_aCacheResources[$sCacheName])) {
            throw new Rama_CacheHandler_Exception(
                __METHOD__ . ' - can not build unrecongnized cache: ' . $sCacheName
                );
        }

        $iDbMcIdentifier = $this->_aCacheResources[$sCacheName]['dbMcIdentifier'];
        
        if ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_SYSTEM) {
            $oDb = $this->_getSystemDb();
            
            $oMemcache = $this->_getSystemMemcache();
        } elseif ($this->_aCacheResources[$sCacheName]['dbType'] === self::DB_USER) {
            $oDb = $this->_getUserDb($iDbMcIdentifier);

            $oMemcache = $this->_getUserMemcache($iDbMcIdentifier);
        } else {
            throw new Rama_CacheHandler_Exception(
                __METHOD__ . ' - unknown dbType'
                );
        }

        try {
            $this->_aCacheResources[$sCacheName]['data'] = call_user_func(
                array($this->_aCacheResources[$sCacheName]['className'], 'build'),
                $this->_aCacheResources[$sCacheName]['args'],
                &$oDb
                );
        } catch (Zend_Db_Adapter_Exception $e) {
            $this->_catchBuilderException($e);
        }
    
        $oMemcache->set(
            $this->_aCacheResources[$sCacheName]['key'],
            array(
                'buildTime'    => time(),
                'lifeTime'     => $this->_aCacheResources[$sCacheName]['lifeTime'],
                'cacheVersion' => $this->_getCacheVersion(),
                'data'         => $this->_aCacheResources[$sCacheName]['data']
                ),
            $this->_aCacheResources[$sCacheName]['lifeTime']
            );
    }
}
