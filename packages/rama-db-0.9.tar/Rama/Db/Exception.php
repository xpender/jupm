<?php
/**
 * X-Rama
 *
 * @author Marko Kercmar <m.kercmar@bigpoint.net>
 * @package net.bigpoint.rama.db
 */
class Rama_Db_Exception extends Rama_Exception
{
}
